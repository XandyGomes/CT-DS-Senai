const express = require("express");
const app = express();

const port = 3000

// ROTA
app.get("/home", (req, res) => {
    res.send("Olá Cliente");
});


app.listen(3000, () => {
   console.log('Servidor rodando em http://localhost:${port}')
});

