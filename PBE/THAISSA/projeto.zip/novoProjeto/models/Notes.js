const mongoose = require('mongoose');

const NotesSchema = new mongoose.Schema({
    lista: { type: String, required: true },
    data: { type: Date, required: true },
})

module.exports = mongoose.model('Notes', NotesSchema)