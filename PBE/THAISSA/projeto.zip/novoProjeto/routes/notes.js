const express = require('express');
const { ObjectId } = require('mongodb');

const router = express.Router();

let notesCollection;

// Inicializa a coleção do MongoDB
function initialize(db) {
    notesCollection = db.collection('notes');
}



// Rota para visualizar a lista de clientes
router.get('/', async (req, res) => {
    try {
        const notes = await notesCollection.find().toArray();
        res.render('notes', { notes });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Rota para exibir o formulário de adicionar nova tarefa
router.get('/add', (req, res) => {
    res.render('adicionar_notes');
});

// Rota para criar uma nova tarefa
router.post('/add', async (req, res) => {
    const { lista, data } = req.body;
    try {
        await notesCollection.insertOne({ lista, data });
        res.redirect('/notes');
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Rota para exibir uma tarefa existente
router.get('/edit/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const notes = await notesCollection.findOne({ _id: new ObjectId(id) });
        res.render('editar_tarefa', { notes });
    } catch (err) { 
        res.status(500).send(err.message);
    }
});

// Rota para processar a atualização das tarefas
router.post('/edit/:id', async (req, res) => {
    const { id } = req.params;
    const { lista, data } = req.body;
    try {
        await notesCollection.updateOne(
            { _id: new ObjectId(id) },
            { $set: { lista,  data} }
        );
        res.redirect('/notes');
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Rota para deletar um cliente
router.post('/delete/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await notesCollection.deleteOne({ _id: new ObjectId(id) });
        res.redirect('/notes');
    } catch (err) {
        res.status(500).send(err.message);
    }
});



module.exports = { router, initialize };
