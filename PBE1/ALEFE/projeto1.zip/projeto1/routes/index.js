var express = require('express');
var router = express.Router();
var db = require('../db') //

/* GET home page. */
router.get('/', function(req, res) {
  global.debug.findAll((e, docs) => { // 
    if(e) {return console.log(e);}
    res.render('index')
  } )
    res.render("index", {docs});
    router.get("/", function (req, res));
      db.findAll(e, docs)
  });

module.exports = router;
