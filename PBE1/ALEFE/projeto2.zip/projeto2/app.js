const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const clienteRoutes = require("./routes/clientes");

const app = express();

//conexão com o banco de dados MongoDB
mongoose.connect("mongodb://localhost:27017/clientes", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log("Conexão com o MongoDB realizada com sucesso!"))
.catch(err => console.log("Erro: " + err));

//configuração do body-parser
app.use(bodyParser.urlencoded({ extended: true})); //para receber dados via POST

//configuração do template ejs
app.set("view engine", "ejs");

//configuração das rotas
app.use("/cliente", clienteRoutes);

//porta
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log('Servidor rodando na porta ${PORT}');
});