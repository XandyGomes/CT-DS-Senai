const express = require('express'); 
const bodyParser = require('body-parser');
const sessionMiddleware = require('./middleware/session');
const customersRoutes = require('./routes/customersRoutes');
const usersRoutes = require('./routes/usersRoutes');
const loginRoutes = require('./routes/loginRoutes'); 
const listCustomersRoutes = require('./routes/listCustomersRoutes');

// Criar uma instância do Express
const app = express();

// Middleware de sessão
app.use(sessionMiddleware);

// Middleware para servir arquivos estáticos
app.use(express.static('public'));

// Middleware para processar dados do formulário
app.use(bodyParser.urlencoded({ extended: false }));

// Definir mecanismo de visualização como EJS
app.set('view engine', 'ejs'); // Define o mecanismo de visualização como EJS

app.use(customersRoutes); // Carrega a rota de clientes
app.use(usersRoutes); // Carrega a rota de usuários
app.use(loginRoutes); // Carrega a rota de login
app.use(listCustomersRoutes); // Carrega a rota de listagem de clientes

// Inicia o servidor na porta 3000
app.listen(3000, () => {
  console.log('Servidor rodando na porta 3000'); 
});