const express = require('express'); // Importa o módulo Express
const router = express.Router(); // Cria uma instância de roteador do Express
const pool = require('../config/database'); // Importa a conexão com o banco de dados
const ensureAuthenticated = require('../middleware/auth'); // Middleware de autenticação

// Rota para listar os clientes (protegida)
router.get('/customers/list', ensureAuthenticated, async (req, res) => {
    try {
        // Busca todos os clientes do banco de dados
        const result = await pool.query('SELECT * FROM customers');

        // Renderiza a página de listagem de clientes com a lista
        res.render('customersList', { customers: result.rows });
    } catch (error) {
        console.error('Erro ao buscar clientes:', error);
        
        // Envia uma mensagem de erro via script para exibir o alert
        res.send(`
            <script>
                alert('Erro ao buscar clientes. Tente novamente.');
                window.location.href = '/customers/list';
            </script>
        `);
    }
});

module.exports = router;
