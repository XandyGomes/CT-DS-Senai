const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const ensureAuthenticated = require('../middleware/auth'); // Importa o middleware

// Rota para exibir o formulário de cadastro de clientes (protege com ensureAuthenticated)
router.get('/customers', ensureAuthenticated, (req, res) => { // Rota protegida por autenticação
  res.render('customers');  // Renderiza a view customers.ejs
});

// Rota para processar o formulário de cadastro de clientes
router.post('/customers', ensureAuthenticated, async (req, res) => { // Rota protegida por autenticação
  const { name, address, city, cpf, rg, phone } = req.body; // Extrai os dados do corpo da requisição

  try { // Tenta inserir o cliente no banco de dados
    const query = 'INSERT INTO customers (name, address, city, cpf, rg, phone) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id'; // Query SQL para inserir um cliente
    const values = [name, address, city, cpf, rg, phone]; // Valores a serem inseridos
    const result = await pool.query(query, values); // Executa a query no banco de dados
    
    res.send(`<script>alert('Cliente cadastrado com sucesso! ID: ${result.rows[0].id}'); window.location.href = '/customers';</script>`); // Exibe um alerta e redireciona para a página de cadastro
  } catch (error) { // Se ocorrer um erro, exibe uma mensagem de erro
    console.error('Erro ao cadastrar cliente:', error); // Exibe o erro no console
    res.send(`<script>alert('Erro ao cadastrar cliente. Tente novamente.'); window.location.href = '/customers';</script>`); // Exibe um alerta e redireciona para a página de cadastro
  }
});

module.exports = router;