const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const bcrypt = require('bcrypt');

// Rota para exibir o formulário de login
router.get('/login', (req, res) => {
  res.render('login');  // Renderiza a view login.ejs
});

// Rota para processar o login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const query = 'SELECT * FROM users WHERE email = $1'; // Query SQL para buscar o usuário
    const result = await pool.query(query, [email]); // Executa a query no banco de dados

    if (result.rows.length > 0) { // Se o usuário foi encontrado no banco de dados 
      const user = result.rows[0]; // Armazena o usuário encontrado
      const isMatch = await bcrypt.compare(password, user.password); // Compara a senha digitada com a senha armazenada

      if (isMatch) { // Se a senha estiver correta
        // Login bem-sucedido, armazena a sessão de autenticação
        req.session.isAuthenticated = true; // Define a sessão como autenticada
        req.session.user = user; // Armazena o usuário na sessão de autenticação
        return res.redirect('/customers'); // Redireciona para a página de clientes
      } else { // Se a senha estiver incorreta
        return res.send(`<script>alert('Senha incorreta.'); window.location.href = '/login';</script>`); // Exibe um alerta e redireciona para o login
      }
    } else { // Se o usuário não foi encontrado no banco de dados
      return res.send(`<script>alert('Usuário não encontrado.'); window.location.href = '/login';</script>`); // Exibe um alerta e redireciona para o login
    }
  } catch (error) { // Se ocorrer um erro, exibe uma mensagem de erro
    console.error('Erro ao processar login:', error); // Exibe o erro no console
    return res.status(500).send('Erro ao processar login.'); // Envia uma mensagem de erro 500
  }
});

// Rota de logout para destruir a sessão
router.get('/logout', (req, res) => { // Rota de logout 
  req.session.destroy(() => { // Destrói a sessão
    res.redirect('/login'); // Redireciona para a página de login
  });
});

module.exports = router;
