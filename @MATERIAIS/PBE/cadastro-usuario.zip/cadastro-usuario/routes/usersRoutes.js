const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const bcrypt = require('bcrypt');

// Rota para exibir o formulário de cadastro de usuários
router.get('/users', (req, res) => {
  res.render('users');  // Renderiza a view users.ejs
});

// Rota para processar o formulário de cadastro de usuários
router.post('/users', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    // Verifica se o usuário já existe
    const userQuery = 'SELECT * FROM users WHERE email = $1'; // Query SQL para buscar o usuário
    const existingUser = await pool.query(userQuery, [email]); // Executa a query no banco de dados

    if (existingUser.rows.length > 0) { // Se o usuário já existir
      // Se o usuário já existir, exibe um alerta e permanece na página de cadastro
      return res.send(`<script>alert('Erro: Email já cadastrado.'); window.location.href = '/users';</script>`);
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(password, 10); // Gera um hash da senha com 10 rounds de salt

    // Inserção do usuário no banco de dados
    const query = 'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING id';
    const values = [name, email, hashedPassword];
    await pool.query(query, values);

    // Se o cadastro for bem-sucedido, exibe um alerta e redireciona para a tela de login
    return res.send(`<script>alert('Usuário cadastrado com sucesso!'); window.location.href = '/login';</script>`);
  } catch (error) { // Se ocorrer um erro, exibe uma mensagem de erro e redireciona para a página de cadastro
    console.error('Erro ao cadastrar usuário:', error);
    return res.send(`<script>alert('Erro ao cadastrar usuário. Tente novamente.'); window.location.href = '/users';</script>`);
  }
});

module.exports = router;