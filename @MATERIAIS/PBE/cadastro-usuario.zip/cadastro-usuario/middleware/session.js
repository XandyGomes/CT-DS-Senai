require('dotenv').config(); // Carrega as variáveis de ambiente
const session = require('express-session'); // Importa o express-session

// Middleware de sessão usando variáveis do .env
const sessionMiddleware = session({ // Configuração do middleware de sessão
  secret: process.env.SESSION_SECRET || 'defaultSecret', // Chave secreta para assinar o cookie
  resave: process.env.SESSION_RESAVE === 'true', // Converte para booleano
  saveUninitialized: process.env.SESSION_SAVE_UNINITIALIZED === 'true', // Converte para booleano 
  cookie: { // Configuração do cookie de sessão
    secure: process.env.SESSION_COOKIE_SECURE === 'true', // Converte para booleano
    maxAge: 1000 * 60 * 2, // Tempo de vida do cookie em milissegundos (2 minutos)
  },
});

module.exports = sessionMiddleware;