function ensureAuthenticated(req, res, next) { // Middleware de autenticação
  if (req.session.isAuthenticated) { // Verifica se o usuário está autenticado
    return next(); // O usuário está autenticado, permite o acesso à rota
  } else { // O usuário não está autenticado
    res.redirect("/login"); // Se não estiver autenticado, redireciona para o login
  }
}

module.exports = ensureAuthenticated;
