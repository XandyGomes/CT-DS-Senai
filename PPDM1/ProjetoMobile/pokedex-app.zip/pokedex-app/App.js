import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Login from './src/screens/Login';
import Register from './src/screens/Register';
import PokemonList from './src/screens/PokemonList';
import PokemonDetails from './src/screens/PokemonDetails'; // Importe a nova tela

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        {/* Telas existentes */}
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="PokemonList" component={PokemonList} />

        {/* Adicione esta nova linha para a tela de detalhes */}
        <Stack.Screen 
          name="PokemonDetails" 
          component={PokemonDetails}
          options={{ title: 'Detalhes do Pokémon' }} // Título personalizado
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
