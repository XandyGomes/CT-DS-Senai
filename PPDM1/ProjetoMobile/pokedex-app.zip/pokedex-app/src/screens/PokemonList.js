import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, ActivityIndicator } from 'react-native';
import PokemonCard from '../components/PokemonCard';

const PokemonList = ({ navigation }) => { // Certifique-se de receber a prop navigation
  const [pokemons, setPokemons] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://pokeapi.co/api/v2/pokemon?limit=50')
      .then((res) => res.json())
      .then((data) => {
        setPokemons(data.results);
        setLoading(false);
      });
  }, []);

  const filteredPokemons = pokemons.filter((pokemon) =>
    pokemon.name.includes(searchTerm.toLowerCase())
  );

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Buscar Pokémon..."
        value={searchTerm}
        onChangeText={setSearchTerm}
        style={{ borderWidth: 1, padding: 10, marginBottom: 10 }}
      />
      {loading ? (
        <ActivityIndicator size="large" />
      ) : (
        <FlatList
          data={filteredPokemons}
          keyExtractor={(item) => item.name}
          renderItem={({ item }) => (
            <PokemonCard 
              name={item.name} 
              url={item.url} 
              navigation={navigation} // Passando a prop navigation
            />
          )}
          numColumns={2} // Layout em 2 colunas
          columnWrapperStyle={{ justifyContent: 'space-between' }}
        />
      )}
    </View>
  );
};

export default PokemonList;