import React, { useState, useEffect } from 'react';
import { View, Text, Image, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';

const PokemonDetails = ({ route }) => {
  const { pokemonUrl } = route.params; // Recebe a URL do Pokémon da navegação
  const [pokemon, setPokemon] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(pokemonUrl)
      .then((res) => res.json())
      .then((data) => {
        setPokemon(data);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <ActivityIndicator size="large" style={styles.loader} />;
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Cabeçalho com imagem e nome */}
      <View style={styles.header}>
        <Image
          source={{ uri: pokemon.sprites.other['official-artwork'].front_default }}
          style={styles.mainImage}
        />
        <Text style={styles.name}>{pokemon.name.toUpperCase()}</Text>
        <Text style={styles.id}>#{pokemon.id.toString().padStart(3, '0')}</Text>
      </View>

      {/* Tipos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Tipos</Text>
        <View style={styles.typesContainer}>
          {pokemon.types.map((type, index) => (
            <Text key={index} style={styles.type}>
              {type.type.name}
            </Text>
          ))}
        </View>
      </View>

      {/* Status Base */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Status</Text>
        {pokemon.stats.map((stat, index) => (
          <View key={index} style={styles.statRow}>
            <Text style={styles.statName}>{stat.stat.name}:</Text>
            <Text style={styles.statValue}>{stat.base_stat}</Text>
          </View>
        ))}
      </View>

      {/* Movimentos (após os primeiros 5) */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Movimentos</Text>
        <View style={styles.movesContainer}>
          {pokemon.moves.slice(0, 5).map((move, index) => (
            <Text key={index} style={styles.move}>
              {move.move.name}
            </Text>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  mainImage: {
    width: 200,
    height: 200,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 10,
  },
  id: {
    color: '#666',
  },
  section: {
    marginBottom: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  typesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  type: {
    padding: 5,
    marginRight: 10,
    backgroundColor: '#78C850',
    color: 'white',
    borderRadius: 5,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  statName: {
    color: '#666',
  },
  statValue: {
    fontWeight: 'bold',
  },
  movesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  move: {
    padding: 5,
    marginRight: 10,
    marginBottom: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 5,
  },
});

export default PokemonDetails;