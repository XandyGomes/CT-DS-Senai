import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const PokemonCard = ({ name, url, navigation }) => {
  const [pokemonDetails, setPokemonDetails] = useState(null);

  useEffect(() => {
    fetch(url)
      .then((res) => res.json())
      .then((data) => setPokemonDetails(data));
  }, [url]);

  return (
    <TouchableOpacity 
      style={styles.card}
      onPress={() => navigation.navigate('PokemonDetails', { pokemonUrl: url })}
    >
      {pokemonDetails && (
        <>
          <Image
            source={{ uri: pokemonDetails.sprites.front_default }}
            style={styles.image}
          />
          <Text style={styles.name}>{name.toUpperCase()}</Text>
          <Text style={styles.id}>#{pokemonDetails.id.toString().padStart(3, '0')}</Text>
          
          {/* Mostrar tipos com cores */}
          <View style={styles.typesContainer}>
            {pokemonDetails.types.map((type, index) => (
              <Text 
                key={index} 
                style={[
                  styles.type,
                  { backgroundColor: getTypeColor(type.type.name) }
                ]}
              >
                {type.type.name}
              </Text>
            ))}
          </View>
        </>
      )}
    </TouchableOpacity>
  );
};

// Função para cores de tipos (adicione após o componente)
const getTypeColor = (type) => {
  const colors = {
    normal: '#A8A878',
    fire: '#F08030',
    water: '#6890F0',
    electric: '#F8D030',
    grass: '#78C850',
    poison: '#A040A0',
    ground: '#E0C068',
    fairy: '#EE99AC',
    // Adicione outros tipos conforme necessário
  };
  return colors[type] || '#777'; // Cor padrão se o tipo não estiver mapeado
};

const styles = StyleSheet.create({
  card: {
    padding: 15,
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 10,
    margin: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  image: { 
    width: 80, 
    height: 80 
  },
  name: { 
    fontWeight: 'bold',
    marginTop: 5,
    fontSize: 16
  },
  id: {
    color: '#666',
    fontSize: 12
  },
  typesContainer: {
    flexDirection: 'row',
    marginTop: 5
  },
  type: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    marginHorizontal: 2,
    borderRadius: 15,
    color: 'white',
    fontSize: 12,
    textTransform: 'capitalize'
  }
});

export default PokemonCard;